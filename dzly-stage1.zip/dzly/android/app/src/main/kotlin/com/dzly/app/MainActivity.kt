package com.dzly.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
