import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../theme/app_theme.dart';

/// شاشة بداية مؤقتة للمرحلة 1: هدفها فقط التأكد أن التطبيق يُبنى ويعمل،
/// وأن الاتصال بـ Supabase تم تهيئته بنجاح (بدون أي شاشات أو منطق حقيقي
/// بعد — تلك تأتي بالمرحلة 2 والمرحلة 3).
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  String _status = 'جارٍ التحقق من الاتصال...';

  @override
  void initState() {
    super.initState();
    _checkConnection();
  }

  Future<void> _checkConnection() async {
    try {
      // فحص بسيط فقط للتأكد أن عميل Supabase تهيّأ بدون رمي استثناء.
      // لا توجد جداول أو استعلامات حقيقية بعد (تأتي بالمرحلة 4)، هذا
      // فقط تأكيد أن Supabase.initialize نجح في main().
      // ignore: unnecessary_type_check
      final client = supabase;
      setState(() {
        _status = client is SupabaseClient
            ? 'تم تهيئة الاتصال بـ Supabase بنجاح ✅\n(لا توجد بيانات بعد — هذه المرحلة 1 فقط)'
            : 'تعذّر تأكيد الاتصال';
      });
    } catch (e) {
      setState(() {
        _status = 'حدث خطأ أثناء التهيئة:\n$e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkGreen,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.chat_bubble_rounded,
                    color: AppColors.white, size: 72),
                const SizedBox(height: 16),
                const Text(
                  'دزلي',
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  _status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.white, fontSize: 14),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
