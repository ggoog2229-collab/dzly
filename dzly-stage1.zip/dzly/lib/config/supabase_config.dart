/// إعدادات الاتصال بـ Supabase.
///
/// ملاحظة أمنية مهمة: القيمتان أدناه هما Project URL ومفتاح anon/publishable
/// العام. هذا المفتاح **مصمم ليكون علنياً** داخل تطبيقات العميل (الهاتف) —
/// الحماية الفعلية لبيانات المستخدمين تأتي من سياسات Row Level Security
/// (RLS) على قاعدة البيانات، وليس من إخفاء هذا المفتاح.
///
/// يُمنع نهائياً وضع service_role key أو كلمة مرور قاعدة البيانات هنا أو في
/// أي ملف يُرفع إلى GitHub — تلك مفاتيح إدارية كاملة الصلاحيات.
class SupabaseConfig {
  static const String url = 'https://mapffacpvoabywrzzauh.supabase.co';
  static const String anonKey =
      'sb_publishable_ggg0V5j81h9e3AaLiIVAFg_WnWdkZGE';
}
