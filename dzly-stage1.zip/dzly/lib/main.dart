import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config/supabase_config.dart';
import 'theme/app_theme.dart';
import 'screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: SupabaseConfig.url,
    anonKey: SupabaseConfig.anonKey,
  );

  runApp(const DzlyApp());
}

/// نقطة دخول موحّدة للوصول لعميل Supabase من أي مكان بالتطبيق.
final supabase = Supabase.instance.client;

class DzlyApp extends StatelessWidget {
  const DzlyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'دزلي',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      // دعم اللغة العربية واتجاه RTL بشكل كامل.
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const SplashScreen(),
    );
  }
}
