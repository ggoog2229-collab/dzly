import 'package:flutter/material.dart';

/// هوية "دزلي" البصرية: أخضر داكن وأبيض مع درجات محايدة.
class AppColors {
  static const Color darkGreen = Color(0xFF0E4D3C);
  static const Color darkGreenDeep = Color(0xFF07332A);
  static const Color accentGreen = Color(0xFF1C8A63);
  static const Color white = Color(0xFFFFFFFF);
  static const Color background = Color(0xFFF5F7F6);
  static const Color surfaceDark = Color(0xFF0B2B22);
  static const Color neutralGrey = Color(0xFF8A938F);
  static const Color error = Color(0xFFB3261E);
}

class AppTheme {
  static ThemeData light() {
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.darkGreen,
        secondary: AppColors.accentGreen,
        error: AppColors.error,
        surface: AppColors.white,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.darkGreen,
        foregroundColor: AppColors.white,
        elevation: 0,
        centerTitle: true,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.darkGreen,
          foregroundColor: AppColors.white,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.neutralGrey.withOpacity(0.4)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.accentGreen, width: 1.6),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      // ملاحظة: لم نُضِف خط "Cairo" الفعلي بعد (يحتاج ملفات خط ترفع لاحقاً
      // ضمن assets/fonts وتُعرّف في pubspec.yaml). حالياً سيستخدم النظام
      // الخط الافتراضي بدون أي خطأ في البناء، ونضيف الخط العربي في مرحلة
      // لاحقة من التصميم.
    );
  }
}
